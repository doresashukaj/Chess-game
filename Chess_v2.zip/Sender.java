import java.io.*;
import java.net.*;
import java.util.*;

class Sender extends Thread {
    Socket s;

    Scanner sc = new Scanner(System.in);
    public void run() {
        try {
			System.out.println("Enter sending port: ");
			int sPort = sc.nextInt();
			s = new Socket("127.0.0.1", sPort);
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void send(String message) throws Exception{
    	// DataInputStream din = new DataInputStream(s.getInputStream());
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());

        dout.writeUTF(message);
    }

    // public static void main(String[] args) throws Exception{
    //     Sender s = new Sender();

    //     s.start();
    //     s.join();
    // }
}