import java.util.*;

public class Main {
    Receiver r;
    Sender s;

    Main () throws Exception{
    	start();
    }
    public void startReceiver() throws Exception{
		r = new Receiver();
		r.start();
		r.join();
    }

    public void startSender() throws Exception {
        s = new Sender();
        s.start();
        s.join();
    }

    void start() throws Exception{
    	Scanner sc = new Scanner(System.in);
		System.out.print("Create or connect: ");
		String ans = sc.nextLine();
		if(ans.equalsIgnoreCase("create")){
			startReceiver();
			startSender();
    		Chess game = new Chess(s, "first");
    		r.setChess(game);
    	} else {
    		startSender();
			startReceiver();
    		Chess game = new Chess(s, "second");
    		r.setChess(game);
    	}
    }

    public static void main(String[] args) throws Exception {
		Main main = new Main();
    }
}