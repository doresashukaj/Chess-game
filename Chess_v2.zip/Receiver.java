import java.io.*;
import java.net.*;
import java.util.*;

class Receiver extends Thread {
    ServerSocket ss;
    Socket s;
    DataInputStream din;
    DataOutput dout;
    Chess chess;

    public void run() {
        try {
        	Scanner sc = new Scanner(System.in);
			System.out.println("Enter receiving port: ");
			int rPort = sc.nextInt();
            ss = new ServerSocket(rPort);
            System.out.println("Receiver created!!!");

            s = ss.accept();
            System.out.println("Client connected");

            new Thread() {
            	public void run(){
            		try {
				      receive();
				    } catch(Exception e) {
				      e.printStackTrace();
				    }
            	}
            }.start();

            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void setChess(Chess chess){
    	this.chess = chess;
    }

    public Chess getChess(){
    	return chess;
    }

    public void receive() throws Exception {
    	din = new DataInputStream(s.getInputStream());
        dout = new DataOutputStream(s.getOutputStream());

        while (true) {
            String str = din.readUTF();
            System.out.println("Message from Client is " + str);
            if(Character.isDigit(str.charAt(0))){
            	String[] splitStr = str.split(" ");
            	chess.moveChessPiece(Integer.parseInt(splitStr[0]), Integer.parseInt(splitStr[1]), Integer.parseInt(splitStr[2]), Integer.parseInt(splitStr[3]), Integer.parseInt(splitStr[4]), Integer.parseInt(splitStr[5]), Integer.parseInt(splitStr[6]), Integer.parseInt(splitStr[7]));
            	
            } else if(str.substring(0,6).equalsIgnoreCase("castle")){
                String[] splitStr = str.split(" ");
                chess.recCastle(Integer.parseInt(splitStr[2]), Integer.parseInt(splitStr[3]), Integer.parseInt(splitStr[4]), splitStr[1].charAt(0));
            }
            if (str.equalsIgnoreCase("bye")) {

                System.out.println("Client left");
                dout.writeUTF(str);
                s.close();
                ss.close();
                this.run();
                break;
            }
        }
    }
}