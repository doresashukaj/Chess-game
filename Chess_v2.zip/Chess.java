import java.awt.*;
import java.awt.event.*;
import java.sql.Time;
import javax.swing.*;
 
public class Chess extends JFrame implements MouseListener, MouseMotionListener {
    JLayeredPane layeredPane;
    JPanel chessBoard;
    JPanel infoPanel;
    JLabel chessPiece;
    int xAdjustment;
    int yAdjustment;

    JPanel infoTimePanel;
    JPanel displayPanel;
    JPanel whiteTimerPanel;
    JPanel whiteTimerDigitsPanel;
    JLabel whiteTimerDigitsLabel;
    JPanel whiteTimerStatusPanel;
    JPanel blackTimerPanel;
    JPanel blackTimerDigitsPanel;
    JLabel blackTimerDigitsLabel;
    JPanel blackTimerStatusPanel;

    Timer whiteTimer;
    Timer blackTimer;

    Time whiteTime;
    Time blackTime;

    JPanel turnPanel;
    JLabel turnLabel;
    
    JScrollPane moveHistoryScrollPane;
    JTextArea moveHistoryTextArea;
    String moveHistoryContent;

    int turns = 0;
    Color color;
    boolean checkmate = false;
    boolean stalemate = false;

    Piece selectedPiece;

    int org_x;
    int org_y;

    int x1;
    int y1;

    int x2;
    int y2;

    Sender s;
    boolean myTurn = false;
 
    public Chess(Sender s, String start) throws Exception{

        this.s = s;
        if(start == "first"){
          myTurn = true;
        }

        Board.startGame();
        Board.printBoard();

        Dimension windowSize = new Dimension(800, 600);
        Dimension boardSize = new Dimension(600, 600);
 
        //  Use a Layered Pane for this this application
 
        layeredPane = new JLayeredPane();
        getContentPane().add(layeredPane);
        layeredPane.setPreferredSize(windowSize);;
        layeredPane.addMouseListener(this);
        layeredPane.addMouseMotionListener(this);

        //Add a chess board to the Layered Pane 
 
         chessBoard = new JPanel();
        layeredPane.add(chessBoard, JLayeredPane.DEFAULT_LAYER);
        chessBoard.setLayout( new GridLayout(8, 8) );
        chessBoard.setPreferredSize( boardSize );
        chessBoard.setBounds(0, 0, boardSize.width, boardSize.height);

        infoPanel = new JPanel(new BorderLayout());
        layeredPane.add(infoPanel, JLayeredPane.DEFAULT_LAYER);
        infoPanel.setPreferredSize(new Dimension(200, 600));
        infoPanel.setBounds(600, 0, 200, 600);
        infoPanel.setBackground(java.awt.Color.RED);

        whiteTimer = new Timer(1000, new ActionListener(){
          public void actionPerformed(ActionEvent e){
            whiteTime.setTime(whiteTime.getTime() + 1000);
            whiteTimerDigitsLabel.setText(whiteTime.toString());
            whiteTimerStatusPanel.setVisible(true);
            blackTimerStatusPanel.setVisible(false);
          }
        });

        blackTimer = new Timer(1000, new ActionListener(){
          public void actionPerformed(ActionEvent e){
            blackTime.setTime(blackTime.getTime() + 1000);
            blackTimerDigitsLabel.setText(blackTime.toString());
            blackTimerStatusPanel.setVisible(true);
            whiteTimerStatusPanel.setVisible(false);
          }
        });
        
        whiteTime = Time.valueOf("00:00:00");
        blackTime = Time.valueOf("00:00:00");
        whiteTimerDigitsLabel = new JLabel(whiteTime.toString());
        whiteTimerDigitsLabel.setFont(whiteTimerDigitsLabel.getFont().deriveFont(38f));
        whiteTimerDigitsPanel = new JPanel();
        whiteTimerDigitsPanel.add(whiteTimerDigitsLabel);
        whiteTimerStatusPanel = new JPanel();
        whiteTimerStatusPanel.setBackground(java.awt.Color.WHITE);
        whiteTimerPanel = new JPanel(new BorderLayout());
        whiteTimerPanel.add(whiteTimerDigitsPanel, BorderLayout.LINE_START);
        whiteTimerPanel.add(whiteTimerStatusPanel, BorderLayout.CENTER);
        whiteTimerPanel.setBorder(BorderFactory.createTitledBorder("White"));

        blackTimerDigitsLabel = new JLabel(blackTime.toString());
        blackTimerDigitsLabel.setFont(blackTimerDigitsLabel.getFont().deriveFont(38f));
        blackTimerDigitsPanel = new JPanel();
        blackTimerDigitsPanel.add(blackTimerDigitsLabel);
        blackTimerStatusPanel = new JPanel();
        blackTimerStatusPanel.setBackground(java.awt.Color.BLACK);
        blackTimerPanel = new JPanel(new BorderLayout());
        blackTimerPanel.add(blackTimerDigitsPanel, BorderLayout.LINE_START);
        blackTimerPanel.add(blackTimerStatusPanel, BorderLayout.CENTER);
        blackTimerPanel.setBorder(BorderFactory.createTitledBorder("Black"));

        displayPanel = new JPanel(new GridLayout(2, 1));
        displayPanel.add(whiteTimerPanel);
        displayPanel.add(blackTimerPanel);

        infoTimePanel = new JPanel(new BorderLayout());
        infoTimePanel.add(displayPanel, BorderLayout.CENTER);
        infoTimePanel.setPreferredSize(new Dimension(200, 200));

        turnPanel = new JPanel(new BorderLayout());
        turnLabel  = new JLabel("", JLabel.CENTER);
        if(start == "first"){
          turnLabel.setText("You're white");
        } else {
          turnLabel.setText("You're black");
        }
        turnPanel.add(turnLabel, BorderLayout.CENTER);
        turnPanel.setPreferredSize(new Dimension(200, 100));

        moveHistoryContent = new String("Game start!\n");
        moveHistoryTextArea = new JTextArea(moveHistoryContent);
        moveHistoryTextArea.setEditable(false);
        moveHistoryTextArea.setBackground(java.awt.Color.GRAY);
        moveHistoryScrollPane = new JScrollPane(moveHistoryTextArea,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        moveHistoryScrollPane.setBorder(BorderFactory.createTitledBorder("Move History"));
        moveHistoryScrollPane.setViewportView(moveHistoryTextArea);
        moveHistoryScrollPane.setPreferredSize(new Dimension(200, 300));

        infoPanel.add(infoTimePanel, BorderLayout.PAGE_START);
        infoPanel.add(turnPanel, BorderLayout.CENTER);
        infoPanel.add(moveHistoryScrollPane, BorderLayout.PAGE_END);
 
        for (int i = 0; i < 64; i++) {
            JPanel square = new JPanel( new BorderLayout() );
            chessBoard.add( square );
 
            int row = (i / 8) % 2;
            if (row == 0)
                square.setBackground( i % 2 == 0 ? java.awt.Color.gray : java.awt.Color.white );
            else
                square.setBackground( i % 2 == 0 ? java.awt.Color.white : java.awt.Color.gray );
        }

        drawBoard();
        checkGame();

        if(myTurn){
          setTitle("Chess: You're White");
        } else {
          setTitle("Chess: You're Black");
        }
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setResizable(true);
        setLocationRelativeTo( null );
        setVisible(true);
    }

    public void updateCell(String icon, int coordinate){
        JLabel piece = new JLabel( new ImageIcon(icon) );
        JPanel panel = (JPanel)chessBoard.getComponent(coordinate);
        panel.add(piece);
    }

    public void switchTimer() {
      if (color == Color.WHITE) {
        whiteTimer.start();
        blackTimer.stop();
      } else if(color == Color.BLACK) {
        blackTimer.start();
        whiteTimer.stop();
      }
    }

    public void drawBoard(){
      updateCell("img/b_rook.png", 0);
      updateCell("img/b_knight.png", 1);
      updateCell("img/b_bishop.png", 2);
      updateCell("img/b_queen.png", 3);
      updateCell("img/b_king.png", 4);
      updateCell("img/b_bishop.png", 5);
      updateCell("img/b_knight.png", 6);
      updateCell("img/b_rook.png", 7);

      updateCell("img/b_pawn.png", 8);
      updateCell("img/b_pawn.png", 9);
      updateCell("img/b_pawn.png", 10);
      updateCell("img/b_pawn.png", 11);
      updateCell("img/b_pawn.png", 12);
      updateCell("img/b_pawn.png", 13);
      updateCell("img/b_pawn.png", 14);
      updateCell("img/b_pawn.png", 15);

      
      updateCell("img/w_rook.png", 56);
      updateCell("img/w_knight.png", 57);
      updateCell("img/w_bishop.png", 58);
      updateCell("img/w_queen.png", 59);
      updateCell("img/w_king.png", 60);
      updateCell("img/w_bishop.png", 61);
      updateCell("img/w_knight.png", 62);
      updateCell("img/w_rook.png", 63);

      updateCell("img/w_pawn.png", 48);
      updateCell("img/w_pawn.png", 49);
      updateCell("img/w_pawn.png", 50);
      updateCell("img/w_pawn.png", 51);
      updateCell("img/w_pawn.png", 52);
      updateCell("img/w_pawn.png", 53);
      updateCell("img/w_pawn.png", 54);
      updateCell("img/w_pawn.png", 55);
    }

    public void checkGame(){
      if (turns % 2 == 0) {
        color = Color.WHITE;
      } else {
        color = Color.BLACK;
      }

      if (Board.staleMate(color) == true) {
        System.out.println("game over, stalemate");
        stalemate = true;
        
        whiteTimer.stop();
        blackTimer.stop();

        JOptionPane.showMessageDialog(this, "Game over, stalemate!", "Stalemate!", JOptionPane.WARNING_MESSAGE);
      }

      if (Board.checkForCheck(color) == true) {
        String checkColor = (color == Color.WHITE) ? "White" : "Black";
        if (Board.mate(color) == true) {
          checkColor = (color == Color.WHITE) ? "Black" : "White";
          System.out.printf("Checkmate, %s wins \n", color == Color.WHITE ? "Black" : "White");
          checkmate = true;

          whiteTimer.stop();
          blackTimer.stop();

          JOptionPane.showMessageDialog(this, "Checkmate, " + checkColor + " wins!", "Checkmate!", JOptionPane.WARNING_MESSAGE);

          return;
        }
        System.out.printf("%s is in Check! \n", color == Color.WHITE ? "White" : "Black");
        JOptionPane.showMessageDialog(this, checkColor + " is in Check!", "Check!", JOptionPane.WARNING_MESSAGE);
      }

      System.out.printf("%s's turn \n", color == Color.WHITE ? "White" : "Black");
      switchTimer();
    }
 
    public void mousePressed(MouseEvent e){
        if(checkmate == true || stalemate == true)
          return;
        if(myTurn == false)
          return;
        chessPiece = null;
        selectedPiece = null;
        Component c =  chessBoard.findComponentAt(e.getX(), e.getY());
 
        if (c instanceof JPanel) 
  return;
 
        Point parentLocation = c.getParent().getLocation();
        xAdjustment = parentLocation.x - e.getX();
        yAdjustment = parentLocation.y - e.getY();

        x1 = parentLocation.x / 75;
        y1 = parentLocation.y / 75;

        Piece piece = Board.getPiece(x1, y1);

        if(piece.getColor() != color)
          return;

        selectedPiece = piece;

        chessPiece = (JLabel)c;
        chessPiece.setLocation(e.getX() + xAdjustment, e.getY() + yAdjustment);
        chessPiece.setSize(chessPiece.getWidth(), chessPiece.getHeight());
        layeredPane.add(chessPiece, JLayeredPane.DRAG_LAYER);

        org_x = e.getX();
        org_y = e.getY();
    }
   
    //Move the chess piece around
    
    public void mouseDragged(MouseEvent me) {
        if(checkmate == true || stalemate == true)
          return;
        if(myTurn == false)
          return;
        if (chessPiece == null) return;
         chessPiece.setLocation(me.getX() + xAdjustment, me.getY() + yAdjustment);
     }
     
  //Drop the chess piece back onto the chess board
 
    public void mouseReleased(MouseEvent e) {
        if(checkmate == true || stalemate == true)
          return;
        if(myTurn == false)
          return;
        if(chessPiece == null) return;

        chessPiece.setVisible(false);
        Component c =  chessBoard.findComponentAt(e.getX(), e.getY());
 
        if (c instanceof JLabel){
            Container parent = c.getParent();
            Point parentLocation = c.getLocation();

            x2 = e.getX() / 75;
            y2 = e.getY() / 75;
            if(selectedPiece.getID() == "king"){
              int sPY = selectedPiece.getY();
              if(Board.getPiece(x2,y2).getID() == "rookQ"){
                if(Board.processMove("castle", "Q", color) == 0){
                  moveHistoryTextArea.append(color + " Castle Queen Side: " + String.valueOf((char)(x1 + 65)) + (8-y1) + " > " + String.valueOf((char)(x2 + 65)) + (8-y2) + "\n");
                  moveHistoryTextArea.repaint();
                  JPanel firstSpace = (JPanel) chessBoard.getComponent(sPY*8+2);
                  firstSpace.add(chessPiece);
                  JPanel secondSpace = (JPanel) chessBoard.getComponent(sPY*8);
                  JLabel secondPiece = (JLabel) secondSpace.getComponent(0);
                  secondSpace.remove(0);
                  JPanel thirdSpace = (JPanel) chessBoard.getComponent(sPY*8+3);
                  thirdSpace.add(secondPiece);
                  secondPiece.repaint();
                  turns++;
                  Board.printBoard();
                  try {
                    s.send("castle Q " + org_x + " " + org_y + " " + sPY + " " + color);
                    myTurn = false;
                  } catch (Exception ue){
                    System.out.println("error comms");
                  }
                } else {
                  layeredPane.remove(0);
                  Component oc =  chessBoard.findComponentAt(org_x, org_y);
                  if (oc instanceof JLabel){
                    Container oparent = oc.getParent();
                    oparent.remove(0);
                    oparent.add( chessPiece );
                  } else {
                    Container oparent = (Container)oc;
                    oparent.add( chessPiece );
                  }
                  System.out.println("illegal move");
                }
              } else if(Board.getPiece(x2,y2).getID() == "rookK"){
                if(Board.processMove("castle", "K", color) == 0){
                  moveHistoryTextArea.append(color + " Castle King Side: " + String.valueOf((char)(x1 + 65)) + (8-y1) + " > " + String.valueOf((char)(x2 + 65)) + (8-y2) + "\n");
                  moveHistoryTextArea.repaint();
                  JPanel firstSpace = (JPanel) chessBoard.getComponent(sPY*8+6);
                  firstSpace.add(chessPiece);
                  JPanel secondSpace = (JPanel) chessBoard.getComponent(sPY*8+7);
                  JLabel secondPiece = (JLabel) secondSpace.getComponent(0);
                  secondSpace.remove(0);
                  JPanel thirdSpace = (JPanel) chessBoard.getComponent(sPY*8+5);
                  thirdSpace.add(secondPiece);
                  secondPiece.repaint();
                  turns++;
                  Board.printBoard();
                  try {
                    s.send("castle K " + org_x + " " + org_y + " " + sPY + " " + color);
                    myTurn = false;
                  } catch (Exception ue){
                    System.out.println("error comms");
                  }
                } else {
                  layeredPane.remove(0);
                  Component oc =  chessBoard.findComponentAt(org_x, org_y);
                  if (oc instanceof JLabel){
                    Container oparent = oc.getParent();
                    oparent.remove(0);
                    oparent.add( chessPiece );
                  } else {
                    Container oparent = (Container)oc;
                    oparent.add( chessPiece );
                  }
                  System.out.println("illegal move");
                }
              }
            } else if(Board.processMove(x1, y1, x2, y2, color) == 0){
              moveHistoryTextArea.append(color + " " + Board.getPiece(x2, y2).toString() + " : " + String.valueOf((char)(x1 + 65)) + (8-y1) + " > " + String.valueOf((char)(x2 + 65)) + (8-y2) + "\n");
              moveHistoryTextArea.repaint();
              parent.remove(0);
              parent.add( chessPiece );
              turns++;
              Board.printBoard();
              try {
                s.send(org_x + " " + org_y + " " + e.getX() + " " + e.getY() + " " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + color);
                myTurn = false;
              } catch (Exception ue){
                System.out.println("error comms");
              }
            } else {
              layeredPane.remove(0);
              Component oc =  chessBoard.findComponentAt(org_x, org_y);
              if (oc instanceof JLabel){
                Container oparent = oc.getParent();
                oparent.remove(0);
                oparent.add( chessPiece );
              } else {
                Container oparent = (Container)oc;
                oparent.add( chessPiece );
              }
              System.out.println("illegal move");
            }
        }
        else {
            Container parent = (Container)c;
            try {
              Point parentLocation = c.getLocation();

              x2 = parentLocation.x / 75;
              y2 = parentLocation.y / 75;
              
              if(Board.processMove(x1, y1, x2, y2, color) == 0){
                moveHistoryTextArea.append(color + " " + Board.getPiece(x2, y2).toString() + " : " + String.valueOf((char)(x1 + 65)) + (8-y1) + " > " + String.valueOf((char)(x2 + 65)) + (8-y2) + "\n");
                moveHistoryTextArea.repaint();
                parent.add( chessPiece );
                turns++;
                Board.printBoard();
                try {
                  s.send(org_x + " " + org_y + " " + e.getX() + " " + e.getY() + " " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + color);
                  myTurn = false;
                } catch (Exception ue){
                  System.out.println("error comms");
                }
              } else {
                layeredPane.remove(0);
                Component oc =  chessBoard.findComponentAt(org_x, org_y);
                if (oc instanceof JLabel){
                  Container oparent = oc.getParent();
                  oparent.remove(0);
                  oparent.add( chessPiece );
                } else {
                  Container oparent = (Container)oc;
                  oparent.add( chessPiece );
                }
                System.out.println("illegal move");
              }
            } catch (NullPointerException npe){
              layeredPane.remove(0);
              Component oc =  chessBoard.findComponentAt(org_x, org_y);
              if (oc instanceof JLabel){
                Container oparent = oc.getParent();
                oparent.remove(0);
                oparent.add( chessPiece );
              } else {
                Container oparent = (Container)oc;
                oparent.add( chessPiece );
              }
            }
            
        }

        selectedPiece = null;
              
        chessPiece.setVisible(true);
 
        checkGame();
    }

    public void recCastle(int fX, int fY, int sPY, char side){
      Component oc = chessBoard.findComponentAt(fX, fY);
      chessPiece = (JLabel) oc;

      if (oc instanceof JLabel){
        Container oparent = oc.getParent();
        oparent.remove(0);
        oparent.repaint();
      }

      if(side == 'Q'){
        Board.processMove("castle", "Q", color);
        turns++;
        Board.printBoard();

        moveHistoryTextArea.append(color + " Castle Queen Side: " + String.valueOf((char)(x1 + 65)) + (8-y1) + " > " + String.valueOf((char)(x2 + 65)) + (8-y2) + "\n");
        moveHistoryTextArea.repaint();

        JPanel firstSpace = (JPanel) chessBoard.getComponent(sPY*8+2);
        firstSpace.add(chessPiece);
        JPanel secondSpace = (JPanel) chessBoard.getComponent(sPY*8);
        JLabel secondPiece = (JLabel) secondSpace.getComponent(0);
        secondSpace.remove(0);
        secondSpace.repaint();
        JPanel thirdSpace = (JPanel) chessBoard.getComponent(sPY*8+3);
        thirdSpace.add(secondPiece);
        secondPiece.repaint();
      } else if(side == 'K'){
        Board.processMove("castle", "K", color);
        turns++;
        Board.printBoard();
        
        moveHistoryTextArea.append(color + " Castle King Side: " + String.valueOf((char)(x1 + 65)) + (8-y1) + " > " + String.valueOf((char)(x2 + 65)) + (8-y2) + "\n");
        moveHistoryTextArea.repaint();

        JPanel firstSpace = (JPanel) chessBoard.getComponent(sPY*8+6);
        firstSpace.add(chessPiece);
        JPanel secondSpace = (JPanel) chessBoard.getComponent(sPY*8+7);
        JLabel secondPiece = (JLabel) secondSpace.getComponent(0);
        secondSpace.remove(0);
        secondSpace.repaint();
        JPanel thirdSpace = (JPanel) chessBoard.getComponent(sPY*8+5);
        thirdSpace.add(secondPiece);
        secondPiece.repaint();
      }

      chessPiece.repaint();

      chessPiece = null;

      checkGame();
      
      myTurn = true;
    }

    public void moveChessPiece(int fX, int fY, int lX, int lY, int x1, int y1, int x2, int y2){
      Board.processMove(x1, y1, x2, y2, color);
      turns++;
      Board.printBoard();
      
      moveHistoryTextArea.append(color + " " + Board.getPiece(x2, y2).toString() + " : " + String.valueOf((char)(x1 + 65)) + (8-y1) + " > " + String.valueOf((char)(x2 + 65)) + (8-y2) + "\n");
      moveHistoryTextArea.repaint();

      Component oc = chessBoard.findComponentAt(fX, fY);
      chessPiece = (JLabel) oc;
      
      if (oc instanceof JLabel){
        Container oparent = oc.getParent();
        oparent.remove(0);
        oparent.repaint();
      }

      Component c = chessBoard.findComponentAt(lX, lY);

      if (c instanceof JLabel){
            Container parent = c.getParent();
            parent.remove(0);
            parent.add(chessPiece);
            parent.repaint();
      } else {
            Container parent = (Container)c;
            parent.add(chessPiece); 
            parent.repaint();           
      }

      chessPiece = null;

      checkGame();
      
      myTurn = true;
    }
 
    public void mouseClicked(MouseEvent e) {
  
    }
    public void mouseMoved(MouseEvent e) {
   }
    public void mouseEntered(MouseEvent e){
  
    }
    public void mouseExited(MouseEvent e) {
  
    }
}


